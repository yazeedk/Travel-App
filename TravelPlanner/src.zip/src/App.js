import React from 'react';
import Cart from './components/travelPlanner';


function App() {
  return (
    <div className="App">
      <Cart />
    </div>
  );
}

export default App;
